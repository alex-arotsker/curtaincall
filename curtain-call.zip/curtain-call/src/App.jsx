import { useState, useEffect } from "react";
/* ═══════════════════════════════════════════
   DATA — Real London shows, March/April 2026
   Heavy on drama — 20 plays, 17 musicals, 2 ballet, 1 opera, 2 comedy
   ═══════════════════════════════════════════ */
const SHOWS_DB = [
  // ── PLAYS / DRAMA ──────────────────────────────────────────────────
  { id: 1,  title: "Romeo & Juliet",                    venue: "Harold Pinter Theatre",       rating: 4.7, critics: 94, audience: 91, img: "🌹", cast: ["Sadie Sink", "Noah Jupe"],                           endDate: "2026-06-07", tags: ["Shakespeare", "Robert Icke"],        category: "Play" },
  { id: 2,  title: "Inter Alia",                        venue: "Duke of York's Theatre",      rating: 4.5, critics: 91, audience: 86, img: "⚖️", cast: ["Rosamund Pike"],                                     endDate: "2026-05-30", tags: ["Legal Drama", "Prima Facie team"],   category: "Play" },
  { id: 3,  title: "Les Liaisons Dangereuses",          venue: "National Theatre, Lyttelton", rating: 4.6, critics: 92, audience: 87, img: "🕯️", cast: ["Lesley Manville", "Aidan Turner", "Monica Barbaro"], endDate: "2026-06-14", tags: ["Laclos Revival", "Seduction"],       category: "Play" },
  { id: 4,  title: "Summerfolk",                        venue: "National Theatre, Olivier",   rating: 4.4, critics: 88, audience: 82, img: "☀️", cast: ["Alex Lawther", "Sophie Rundle"],                    endDate: "2026-06-20", tags: ["Gorky", "Ensemble"],                 category: "Play" },
  { id: 5,  title: "One Flew Over the Cuckoo's Nest",  venue: "The Old Vic",                 rating: 4.5, critics: 90, audience: 88, img: "🏥", cast: ["Aaron Pierre", "Giles Terera"],                     endDate: "2026-05-23", tags: ["Classic", "Clint Dyer"],             category: "Play" },
  { id: 6,  title: "Grace Pervades",                    venue: "Theatre Royal Haymarket",     rating: 4.6, critics: 92, audience: 85, img: "🎩", cast: ["Ralph Fiennes", "Miranda Raison"],                  endDate: "2026-07-11", tags: ["David Hare", "Victorian Drama"],     category: "Play" },
  { id: 7,  title: "Shadowlands",                       venue: "Aldwych Theatre",             rating: 4.5, critics: 90, audience: 89, img: "📖", cast: ["Hugh Bonneville"],                                  endDate: "2026-06-06", tags: ["C.S. Lewis", "Grief"],               category: "Play" },
  { id: 8,  title: "Copenhagen",                        venue: "Wyndhams Theatre",            rating: 4.5, critics: 91, audience: 84, img: "⚛️", cast: ["Alex Kingston", "Richard Schiff", "Damien Molony"], endDate: "2026-05-02", tags: ["Michael Frayn", "WWII"],             category: "Play" },
  { id: 9,  title: "Teeth 'N' Smiles",                  venue: "Harold Pinter Theatre",       rating: 4.3, critics: 86, audience: 83, img: "🎸", cast: ["Rebecca Lucy Taylor (Self Esteem)"],                endDate: "2026-05-09", tags: ["David Hare", "Rock Drama"],          category: "Play" },
  { id: 10, title: "Broken Glass",                      venue: "The Young Vic",               rating: 4.4, critics: 89, audience: 82, img: "🪟", cast: ["Nancy Carroll"],                                    endDate: "2026-04-26", tags: ["Arthur Miller", "1930s"],            category: "Play" },
  { id: 11, title: "The Price",                         venue: "Wyndham's Theatre",           rating: 4.4, critics: 88, audience: 85, img: "🛋️", cast: ["Henry Goodman"],                                   endDate: "2026-06-07", tags: ["Arthur Miller", "Family"],           category: "Play" },
  { id: 12, title: "1536",                              venue: "Ambassadors Theatre",          rating: 4.4, critics: 88, audience: 87, img: "👑", cast: ["Ava Pickett — debut play"],                         endDate: "2026-06-20", tags: ["Anne Boleyn", "New Writing"],        category: "Play" },
  { id: 13, title: "A Doll's House",                    venue: "Almeida Theatre",             rating: 4.5, critics: 90, audience: 85, img: "🚪", cast: ["Romola Garai"],                                    endDate: "2026-05-17", tags: ["Ibsen", "Feminist"],                 category: "Play" },
  { id: 14, title: "Man to Man",                        venue: "Royal Court Theatre",         rating: 4.4, critics: 89, audience: 83, img: "🎭", cast: ["Tilda Swinton"],                                    endDate: "2026-04-25", tags: ["Solo Show", "Avant-garde"],          category: "Play" },
  { id: 15, title: "Marie & Rosetta",                   venue: "Soho Theatre",                rating: 4.4, critics: 88, audience: 87, img: "🎸", cast: ["Beverley Knight"],                                   endDate: "2026-04-11", tags: ["Gospel", "True Story"],              category: "Play" },
  { id: 16, title: "John Proctor is the Villain",       venue: "Garrick Theatre",             rating: 4.4, critics: 88, audience: 86, img: "🔥", cast: ["Various"],                                          endDate: "2026-05-09", tags: ["Broadway Transfer", "New Writing"],   category: "Play" },
  { id: 17, title: "Oh, Mary!",                         venue: "Trafalgar Theatre",           rating: 4.4, critics: 86, audience: 93, img: "🎭", cast: ["Mason Alexander Park", "Catherine Tate from Apr 27"], endDate: "2026-07-18", tags: ["Dark Comedy", "Tony-winner"],       category: "Play" },
  { id: 18, title: "Dracula",                           venue: "Barbican Theatre",            rating: 4.5, critics: 91, audience: 87, img: "🦇", cast: ["Cynthia Erivo — solo, 23 roles"],                   endDate: null,         tags: ["Solo Show", "Gothic"],              category: "Play" },
  { id: 19, title: "Witness for the Prosecution",       venue: "County Hall",                 rating: 4.3, critics: 84, audience: 90, img: "🔍", cast: ["Various — immersive staging"],                      endDate: null,         tags: ["Agatha Christie", "Immersive"],      category: "Play" },
  { id: 20, title: "Harry Potter and the Cursed Child", venue: "Palace Theatre",              rating: 4.3, critics: 84, audience: 89, img: "⚡", cast: ["Various"],                                          endDate: null,         tags: ["Epic", "Magic"],                     category: "Play" },
  { id: 21, title: "Stranger Things: The First Shadow", venue: "Phoenix Theatre",             rating: 4.1, critics: 80, audience: 88, img: "👾", cast: ["Various"],                                          endDate: "2026-04-05", tags: ["Sci-Fi", "Last Chance"],             category: "Play" },
  { id: 22, title: "The Mousetrap",                     venue: "St Martin's Theatre",         rating: 4.2, critics: 78, audience: 90, img: "🐭", cast: ["Various"],                                          endDate: null,         tags: ["Agatha Christie", "75 Years"],       category: "Play" },
  // ── MUSICALS ───────────────────────────────────────────────────────
  { id: 23, title: "Les Misérables",                    venue: "Sondheim Theatre",            rating: 4.7, critics: 93, audience: 95, img: "🏴", cast: ["Various"],                                          endDate: "2027-03-13", tags: ["Classic", "Epic"],                   category: "Musical" },
  { id: 24, title: "Hamilton",                          venue: "Victoria Palace Theatre",     rating: 4.5, critics: 91, audience: 92, img: "⭐", cast: ["Various"],                                          endDate: null,         tags: ["Hip-Hop", "History"],               category: "Musical" },
  { id: 25, title: "Hadestown",                         venue: "Lyric Theatre",               rating: 4.6, critics: 89, audience: 93, img: "🔥", cast: ["Clive Rowe as Hermes"],                             endDate: null,         tags: ["Mythology", "Folk"],                 category: "Musical" },
  { id: 26, title: "Mamma Mia!",                        venue: "Novello Theatre",             rating: 4.3, critics: 82, audience: 94, img: "🎵", cast: ["Various"],                                          endDate: null,         tags: ["Feel-Good", "ABBA"],                 category: "Musical" },
  { id: 27, title: "Kinky Boots",                       venue: "London Coliseum",             rating: 4.4, critics: 86, audience: 93, img: "👠", cast: ["Johannes Radebe", "Matt Cardle"],                  endDate: "2026-07-11", tags: ["Revival", "Cyndi Lauper"],           category: "Musical" },
  { id: 28, title: "Back to the Future: The Musical",   venue: "Adelphi Theatre",             rating: 4.3, critics: 84, audience: 91, img: "⚡", cast: ["Various"],                                          endDate: "2026-04-12", tags: ["Last Chance", "Spectacle"],          category: "Musical" },
  { id: 29, title: "Operation Mincemeat",               venue: "Fortune Theatre",             rating: 4.5, critics: 90, audience: 95, img: "🎖️", cast: ["Various"],                                         endDate: null,         tags: ["Comedy", "Olivier Winner"],          category: "Musical" },
  { id: 30, title: "Oliver!",                           venue: "Gielgud Theatre",             rating: 4.4, critics: 87, audience: 90, img: "🎩", cast: ["dir. Matthew Bourne"],                              endDate: null,         tags: ["Revival", "Dickens"],                category: "Musical" },
  { id: 31, title: "Six",                               venue: "Vaudeville Theatre",          rating: 4.4, critics: 86, audience: 94, img: "👑", cast: ["Various"],                                          endDate: null,         tags: ["Pop", "Tudor"],                      category: "Musical" },
  { id: 32, title: "The Phantom of the Opera",          venue: "His Majesty's Theatre",       rating: 4.5, critics: 88, audience: 91, img: "🎭", cast: ["Various"],                                          endDate: null,         tags: ["Classic", "Lloyd Webber"],           category: "Musical" },
  { id: 33, title: "Avenue Q",                          venue: "Shaftesbury Theatre",         rating: 4.3, critics: 85, audience: 92, img: "🪆", cast: ["Various — 20th Anniversary"],                       endDate: "2026-08-29", tags: ["Adult Comedy", "Puppets"],           category: "Musical" },
  { id: 34, title: "Moulin Rouge! The Musical",         venue: "Piccadilly Theatre",          rating: 4.4, critics: 86, audience: 90, img: "🌹", cast: ["Various"],                                          endDate: null,         tags: ["Glam", "Spectacle"],                 category: "Musical" },
  { id: 35, title: "My Neighbour Totoro",               venue: "Gillian Lynne Theatre",       rating: 4.6, critics: 92, audience: 96, img: "🌳", cast: ["RSC — Olivier Winner"],                             endDate: null,         tags: ["Family", "Magical"],                 category: "Musical" },
  { id: 36, title: "The Producers",                     venue: "Garrick Theatre",             rating: 4.2, critics: 83, audience: 88, img: "🎬", cast: ["Various"],                                          endDate: null,         tags: ["Mel Brooks", "Comedy"],              category: "Musical" },
  { id: 37, title: "Starlight Express",                 venue: "Troubadour Wembley Park",     rating: 4.3, critics: 84, audience: 89, img: "🚂", cast: ["Various — 40th Anniversary"],                       endDate: null,         tags: ["Lloyd Webber", "Spectacle"],         category: "Musical" },
  { id: 38, title: "The Devil Wears Prada",             venue: "Dominion Theatre",            rating: 4.0, critics: 76, audience: 84, img: "👗", cast: ["Vanessa Williams"],                                  endDate: null,         tags: ["Fashion", "New Musical"],            category: "Musical" },
  // ── OPERA ──────────────────────────────────────────────────────────
  { id: 39, title: "La Bohème",                         venue: "ENO Coliseum",                rating: 4.4, critics: 87, audience: 83, img: "🎶", cast: ["Various"],                                          endDate: "2026-04-15", tags: ["Romantic", "Puccini"],              category: "Opera" },
  // ── BALLET & DANCE ─────────────────────────────────────────────────
  { id: 40, title: "Swan Lake",                         venue: "Royal Opera House",           rating: 4.8, critics: 95, audience: 92, img: "🦢", cast: ["Royal Ballet"],                                     endDate: "2026-05-01", tags: ["Classic", "ROH"],                    category: "Ballet & Dance" },
  { id: 41, title: "Crystal Pite & Kameron Saunders",  venue: "Sadler's Wells",              rating: 4.4, critics: 89, audience: 84, img: "🌀", cast: ["Crystal Pite", "Kameron N. Saunders"],              endDate: "2026-04-12", tags: ["Contemporary", "World Premiere"],    category: "Ballet & Dance" },
  // ── COMEDY ─────────────────────────────────────────────────────────
  { id: 42, title: "The Play That Goes Wrong",          venue: "Duchess Theatre",             rating: 4.5, critics: 88, audience: 96, img: "😂", cast: ["Mischief Theatre"],                                 endDate: "2027-01-01", tags: ["Slapstick", "Olivier Winner"],       category: "Comedy" },
  { id: 43, title: "Murder, She Didn't Write",          venue: "Criterion Theatre",           rating: 4.3, critics: 85, audience: 93, img: "🔍", cast: ["Various — improvised"],                             endDate: "2026-05-18", tags: ["Improv", "Edinburgh Hit"],           category: "Comedy" },
];

const CATEGORIES = ["All", "Play", "Musical", "Opera", "Ballet & Dance", "Comedy"];

const FRIENDS = [
  { id: 1, name: "Nona",     avatar: "🌺", showsLogged: 24,  topShow: "Swan Lake",          match: 87 },
  { id: 2, name: "James T.", avatar: "🎬", showsLogged: 67,  topShow: "Copenhagen",         match: 72 },
  { id: 3, name: "Sophie K.",avatar: "🎭", showsLogged: 112, topShow: "Romeo & Juliet",     match: 91 },
  { id: 4, name: "Marcus W.",avatar: "🎵", showsLogged: 43,  topShow: "Hadestown",          match: 65 },
  { id: 5, name: "Priya L.", avatar: "✨", showsLogged: 89,  topShow: "Les Misérables",     match: 78 },
];

const FEED_ITEMS = [
  { user: "Sophie K.", avatar: "🎭", show: "Romeo & Juliet",               showCategory: "Play",    rating: 5,   text: "Sadie Sink is extraordinary. Icke strips every cliché — this feels genuinely dangerous, genuinely young. Noah Jupe matches her beat for beat. The Harold Pinter has never felt so electric. Best thing I've seen in years.", time: "3h ago",  likes: 22, tags: ["Must-See"] },
  { user: "James T.", avatar: "🎬", show: "Copenhagen",                    showCategory: "Play",    rating: 5,   text: "Alex Kingston and Richard Schiff are mesmerising. Frayn's play shouldn't work — three dead scientists in a limbo room arguing physics — and yet it's the most gripping ninety minutes in the West End right now. First revival since 1998 and worth every year of the wait.", time: "5h ago",  likes: 18, tags: ["Mind-Blown"] },
  { user: "Nona",     avatar: "🌺", show: "Shadowlands",                   showCategory: "Play",    rating: 4.5, text: "Brought me to pieces. Hugh Bonneville gives everything — the shift from buttoned-up don to a man devastated by love and grief is extraordinarily precise. The Aldwych is the perfect house for it. Have tissues ready.", time: "1d ago",  likes: 14, tags: ["Emotional"] },
  { user: "Priya L.", avatar: "✨", show: "One Flew Over the Cuckoo's Nest",showCategory: "Play",   rating: 5,   text: "Aaron Pierre is a force of nature. Clint Dyer's staging feels urgent and modern without losing any of Kesey's original power. The ensemble around Pierre is exceptional. The Old Vic at its very best.", time: "2d ago",  likes: 19, tags: ["Must-See"] },
  { user: "Marcus W.",avatar: "🎵", show: "Inter Alia",                    showCategory: "Play",    rating: 4.5, text: "Rosamund Pike is ferocious. Suzie Miller knows exactly how to use a courtroom — the script is tighter than Prima Facie and the direction is stunning. Absolutely gripping from first to last.", time: "3d ago",  likes: 11, tags: ["Drama"] },
];

const MY_LOGGED = [
  { show: "Romeo & Juliet",                   rating: 4.8, date: "2026-03-18", rank: 1,  category: "Play",          categoryRank: 1 },
  { show: "Swan Lake",                         rating: 4.7, date: "2026-03-01", rank: 2,  category: "Ballet & Dance",categoryRank: 1 },
  { show: "Les Misérables",                    rating: 4.7, date: "2026-03-20", rank: 3,  category: "Musical",       categoryRank: 1 },
  { show: "Copenhagen",                        rating: 4.7, date: "2026-03-28", rank: 4,  category: "Play",          categoryRank: 2 },
  { show: "One Flew Over the Cuckoo's Nest",   rating: 4.6, date: "2026-02-22", rank: 5,  category: "Play",          categoryRank: 3 },
  { show: "Hadestown",                         rating: 4.5, date: "2026-02-14", rank: 6,  category: "Musical",       categoryRank: 2 },
  { show: "Inter Alia",                        rating: 4.5, date: "2026-03-12", rank: 7,  category: "Play",          categoryRank: 4 },
  { show: "Shadowlands",                       rating: 4.5, date: "2026-03-05", rank: 8,  category: "Play",          categoryRank: 5 },
  { show: "Operation Mincemeat",               rating: 4.4, date: "2026-02-01", rank: 9,  category: "Musical",       categoryRank: 3 },
  { show: "La Bohème",                         rating: 4.4, date: "2026-01-15", rank: 10, category: "Opera",         categoryRank: 1 },
  { show: "The Play That Goes Wrong",          rating: 4.5, date: "2025-12-28", rank: 11, category: "Comedy",        categoryRank: 1 },
];

const TASTE_PROFILE = {
  totalShows: 31, avgRating: 4.32,
  badges: ["Opening Night Regular", "Drama Devotee", "Fringe Explorer", "Culture Vulture"],
  genreBreakdown: { Play: 40, Musical: 35, Opera: 10, "Ballet & Dance": 9, Comedy: 6 },
};

/* ═══════════════════════════════════════════
   SHARED COMPONENTS
   ═══════════════════════════════════════════ */
const StarRating = ({ rating, size = 14 }) => {
  const full = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.3;
  return (
    <span style={{ display: "inline-flex", gap: 1, fontSize: size }}>
      {[...Array(5)].map((_, i) => (
        <span key={i} style={{ color: i < full + (hasHalf && i === full ? 1 : 0) ? "#c8860a" : "#d8d3cc" }}>★</span>
      ))}
    </span>
  );
};
const RankBadge = ({ rank }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    width: 24, height: 24, borderRadius: "50%", fontSize: 11, fontWeight: 700,
    background: rank === 1 ? "linear-gradient(135deg,#c8860a,#e0a832)" : rank === 2 ? "linear-gradient(135deg,#8a8580,#aaa)" : rank === 3 ? "linear-gradient(135deg,#a0704a,#c09060)" : "#f0ece6",
    color: rank <= 3 ? "#fff" : "#8a8580", border: rank > 3 ? "1.5px solid #ddd7cf" : "none",
    flexShrink: 0, boxShadow: rank <= 3 ? "0 2px 6px rgba(0,0,0,0.12)" : "none"
  }}>{rank}</span>
);
const Tag = ({ label, accent }) => (
  <span style={{
    display: "inline-block", padding: "3px 10px",
    background: accent ? "rgba(200,134,10,0.08)" : "#f5f1ec",
    color: accent ? "#c8860a" : "#6a6560", borderRadius: 20, fontSize: 10, fontWeight: 600,
    letterSpacing: 0.4, textTransform: "uppercase"
  }}>{label}</span>
);
const CategoryPill = ({ label, active, onClick, count }) => (
  <button onClick={onClick} style={{
    background: active ? "#1a1816" : "#fff", color: active ? "#fff" : "#6a6560",
    border: active ? "none" : "1.5px solid #e8e3dc", borderRadius: 24, padding: "7px 16px",
    fontSize: 12, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
    whiteSpace: "nowrap", transition: "all 0.2s", boxShadow: active ? "0 2px 8px rgba(0,0,0,0.12)" : "none"
  }}>
    {label}
    {count != null && <span style={{ fontSize: 10, background: active ? "rgba(255,255,255,0.2)" : "#f0ece6", padding: "1px 6px", borderRadius: 10 }}>{count}</span>}
  </button>
);
const CompareModal = ({ show, category, existingShows, onClose }) => {
  const [step, setStep] = useState(0);
  const comparisons = existingShows.filter(s => s.category === category).slice(0, 3);
  if (comparisons.length === 0) return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:20,backdropFilter:"blur(8px)" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",borderRadius:20,padding:32,maxWidth:380,width:"100%",textAlign:"center" }}>
        <p style={{ fontSize:40,margin:"0 0 12px" }}>🎉</p>
        <h3 style={{ fontSize:20,margin:"0 0 8px",color:"#1a1816" }}>First in {category}!</h3>
        <p style={{ color:"#8a8580",fontSize:14,margin:"0 0 20px" }}>It takes the #1 spot automatically.</p>
        <button onClick={onClose} style={{ background:"#1a1816",color:"#fff",border:"none",borderRadius:12,padding:"12px 32px",fontSize:14,fontWeight:600,cursor:"pointer" }}>Done</button>
      </div>
    </div>
  );
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:20,backdropFilter:"blur(8px)" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",borderRadius:20,padding:28,maxWidth:380,width:"100%" }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4 }}>
          <Tag label={category} accent />
          <span style={{ fontSize:12,color:"#b5b0ab" }}>{step+1}/{comparisons.length}</span>
        </div>
        <h3 style={{ color:"#1a1816",fontSize:20,margin:"12px 0 4px" }}>Which did you prefer?</h3>
        <p style={{ color:"#8a8580",fontSize:13,margin:"0 0 20px" }}>Ranking within <strong>{category}</strong> only</p>
        <div style={{ display:"flex",gap:6,marginBottom:20,justifyContent:"center" }}>
          {comparisons.map((_,i)=><div key={i} style={{ width:8,height:8,borderRadius:"50%",background:i<=step?"#c8860a":"#e8e3dc" }}/>)}
        </div>
        {[{ label:show,sub:"NEW",color:"#c8860a" },{ label:comparisons[step].show,sub:`#${comparisons[step].categoryRank} in ${category}`,color:"#8a8580" }].map((opt,i)=>(
          <div key={i}>
            {i===1 && <div style={{ textAlign:"center",color:"#b5b0ab",fontSize:11,letterSpacing:2,margin:"10px 0" }}>OR</div>}
            <button onClick={()=>step<comparisons.length-1?setStep(step+1):onClose()} style={{ width:"100%",background:"#faf8f5",border:"2px solid #e8e3dc",borderRadius:14,padding:"18px 20px",color:"#1a1816",cursor:"pointer",textAlign:"left",fontSize:16,fontWeight:600,transition:"all 0.2s" }}
              onMouseEnter={e=>{ e.currentTarget.style.borderColor="#c8860a"; }}
              onMouseLeave={e=>{ e.currentTarget.style.borderColor="#e8e3dc"; }}
            >{opt.label} <span style={{ fontSize:11,color:opt.color,marginLeft:6 }}>{opt.sub}</span></button>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════
   LANDING PAGE
   ═══════════════════════════════════════════ */
const LandingPage = ({ onEnter }) => {
  const [vis, setVis] = useState(new Array(8).fill(false));
  useEffect(() => {
    [...Array(8)].forEach((_,i) => setTimeout(() => setVis(v=>{ const n=[...v]; n[i]=true; return n; }), 150+i*180));
  }, []);
  const step = (num,icon,title,desc,sub,delay) => (
    <div style={{ display:"flex",gap:18,alignItems:"flex-start",opacity:vis[delay]?1:0,transform:vis[delay]?"translateY(0)":"translateY(24px)",transition:"all 0.6s cubic-bezier(0.16,1,0.3,1)" }}>
      <div style={{ width:52,height:52,borderRadius:14,background:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0,border:"1px solid #ebe6df",boxShadow:"0 2px 8px rgba(0,0,0,0.04)" }}>{icon}</div>
      <div>
        <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:5 }}>
          <span style={{ fontSize:11,fontWeight:700,color:"#c8860a",fontFamily:"'JetBrains Mono',monospace" }}>{num}</span>
          <h3 style={{ margin:0,fontSize:17,fontWeight:700,color:"#1a1816" }}>{title}</h3>
        </div>
        <p style={{ margin:"0 0 6px",fontSize:14,color:"#4a4540",lineHeight:1.6 }}>{desc}</p>
        {sub && <p style={{ margin:0,fontSize:12,color:"#9a9590",lineHeight:1.5,fontStyle:"italic" }}>{sub}</p>}
      </div>
    </div>
  );
  return (
    <div style={{ minHeight:"100vh",background:"#faf8f5",display:"flex",justifyContent:"center",fontFamily:"'DM Sans',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
      <div style={{ width:"100%",maxWidth:430,position:"relative",overflow:"hidden" }}>
        <div style={{ padding:"60px 28px 36px",textAlign:"center",position:"relative",background:"radial-gradient(ellipse at 50% 0%,rgba(200,134,10,0.07) 0%,transparent 70%)" }}>
          <div style={{ position:"absolute",top:0,left:0,right:0,height:4,background:"linear-gradient(90deg,transparent 0%,#c8860a 20%,#c8860a 80%,transparent 100%)",opacity:0.3 }}/>
          <div style={{ opacity:vis[0]?1:0,transform:vis[0]?"translateY(0)":"translateY(20px)",transition:"all 0.7s cubic-bezier(0.16,1,0.3,1)" }}>
            <div style={{ display:"inline-flex",alignItems:"center",gap:8,background:"rgba(200,134,10,0.06)",border:"1px solid rgba(200,134,10,0.12)",borderRadius:24,padding:"6px 16px",marginBottom:24 }}>
              <span style={{ fontSize:14 }}>🎭</span>
              <span style={{ fontSize:11,color:"#c8860a",fontWeight:600,fontFamily:"'JetBrains Mono',monospace",letterSpacing:0.5 }}>FOR THEATRE LOVERS</span>
            </div>
            <h1 style={{ fontFamily:"'Playfair Display',serif",fontSize:42,fontWeight:700,color:"#1a1816",lineHeight:1.1,margin:"0 0 16px",letterSpacing:-1 }}>Curtain<br/>Call</h1>
            <p style={{ fontSize:18,color:"#1a1816",fontWeight:600,lineHeight:1.4,margin:"0 auto 10px",maxWidth:300 }}>Your theatre diary, your rankings, your tribe.</p>
            <p style={{ fontSize:14,color:"#8a8580",lineHeight:1.65,margin:"0 auto 28px",maxWidth:320 }}>Log every show you see. Build a ranked list per category — plays vs plays, musicals vs musicals. See what your friends are watching and how your tastes match.</p>
          </div>
          <div style={{ display:"flex",justifyContent:"center",gap:10,marginBottom:8,opacity:vis[1]?1:0,transform:vis[1]?"translateY(0)":"translateY(30px)",transition:"all 0.8s cubic-bezier(0.16,1,0.3,1)" }}>
            {[
              { emoji:"🌹",title:"Romeo & Juliet",r:4.7,cat:"Play",tilt:-3 },
              { emoji:"🦢",title:"Swan Lake",r:4.8,cat:"Ballet",tilt:0 },
              { emoji:"⚛️",title:"Copenhagen",r:4.5,cat:"Play",tilt:3 },
            ].map((c,i)=>(
              <div key={i} style={{ background:"#fff",borderRadius:16,padding:"14px 12px 12px",width:108,border:"1px solid #ebe6df",boxShadow:"0 4px 16px rgba(0,0,0,0.06)",transform:`rotate(${c.tilt}deg)`,textAlign:"center" }}>
                <div style={{ fontSize:28,marginBottom:6 }}>{c.emoji}</div>
                <p style={{ margin:"0 0 3px",fontSize:12,fontWeight:700,color:"#1a1816" }}>{c.title}</p>
                <StarRating rating={c.r} size={10}/>
                <div style={{ marginTop:5 }}><Tag label={c.cat} accent/></div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ padding:"32px 28px" }}>
          <div style={{ opacity:vis[1]?1:0,transition:"all 0.5s ease",display:"flex",alignItems:"center",gap:8,marginBottom:30 }}>
            <div style={{ height:1,flex:1,background:"#ebe6df" }}/><span style={{ fontSize:10,color:"#b5b0ab",fontFamily:"'JetBrains Mono',monospace",letterSpacing:3,textTransform:"uppercase" }}>How it works</span><div style={{ height:1,flex:1,background:"#ebe6df" }}/>
          </div>
          <div style={{ display:"flex",flexDirection:"column",gap:32 }}>
            {step("01","⭐","Log a show","Seen something? Rate it out of five stars, write a quick review, and tag the vibe — Mind-Blown, Date Night, Overrated, Must-See. It goes straight into your permanent record.","Plays, musicals, opera, ballet, comedy — all five categories covered.",2)}
            {step("02","⚖️","Rank it head-to-head","After logging, you compare head-to-head within the same category. Was this better than the last play you saw? After a few quick choices, your ranked list builds itself. No more star-rating paralysis.","Plays only compete against plays. Musicals against musicals. No apples vs oranges.",3)}
            {step("03","👥","Follow your people","See your friends' reviews in a live feed. A taste-match score tells you instantly who to trust — if Sophie's at 91%, her recommendation is basically gospel.","Find out who your theatrical soulmate is.",4)}
            {step("04","🎯","Discover what's next","Browse everything running near you, filtered by category. Check critic vs audience scores, wishlist shows before they sell out, and get a heads-up when something's about to close.",null,5)}
          </div>
        </div>
        <div style={{ padding:"24px 28px",background:"#fff",borderTop:"1px solid #ebe6df",borderBottom:"1px solid #ebe6df",opacity:vis[5]?1:0,transition:"all 0.6s ease" }}>
          <div style={{ display:"flex",justifyContent:"center",gap:8,marginBottom:12 }}>
            {FRIENDS.slice(0,5).map(f=>(
              <div key={f.id} style={{ width:36,height:36,borderRadius:"50%",background:"#f5f1ec",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,border:"2px solid #fff",marginLeft:f.id>1?-8:0,position:"relative",zIndex:6-f.id }}>{f.avatar}</div>
            ))}
          </div>
          <p style={{ textAlign:"center",fontSize:13,color:"#6a6560",margin:0 }}>Join <strong style={{ color:"#1a1816" }}>your theatre-going friends</strong> already on Curtain Call</p>
        </div>
        <div style={{ padding:"40px 28px 0",textAlign:"center",opacity:vis[6]?1:0,transform:vis[6]?"translateY(0)":"translateY(16px)",transition:"all 0.6s ease" }}>
          <p style={{ fontFamily:"'Playfair Display',serif",fontSize:22,fontStyle:"italic",color:"#1a1816",lineHeight:1.4,margin:"0 0 6px" }}>"Letterboxd for the stage."</p>
          <p style={{ fontSize:13,color:"#b5b0ab",margin:"0 0 28px" }}>Plays · Musicals · Opera · Ballet · Comedy</p>
          <div style={{ background:"rgba(200,134,10,0.04)",border:"1px solid rgba(200,134,10,0.14)",borderRadius:16,padding:"18px 20px",marginBottom:32,textAlign:"left",opacity:vis[7]?1:0,transform:vis[7]?"translateY(0)":"translateY(12px)",transition:"all 0.6s cubic-bezier(0.16,1,0.3,1)" }}>
            <p style={{ fontSize:13,color:"#6a6560",margin:"0 0 10px",lineHeight:1.6 }}><span style={{ fontFamily:"'Playfair Display',serif",fontStyle:"italic",color:"#1a1816" }}>"No one cares about [opera and ballet] anymore."</span></p>
            <p style={{ fontSize:11,color:"#b5b0ab",margin:"0 0 12px",fontFamily:"'JetBrains Mono',monospace" }}>— Timothée Chalamet, February 2026</p>
            <p style={{ fontSize:13,color:"#4a4540",margin:0,fontWeight:600,lineHeight:1.5 }}>This app is for everyone who does. Log your Swan Lake. Rank your Frayn. Make Timothée irrelevant. 🦢</p>
          </div>
          <button onClick={onEnter} style={{ background:"#1a1816",color:"#fff",border:"none",borderRadius:14,padding:"16px 48px",fontSize:16,fontWeight:700,cursor:"pointer",fontFamily:"'DM Sans',sans-serif",letterSpacing:0.3,boxShadow:"0 4px 20px rgba(0,0,0,0.12)",transition:"transform 0.15s" }}
            onMouseEnter={e=>e.target.style.transform="scale(1.03)"}
            onMouseLeave={e=>e.target.style.transform="scale(1)"}
          >Try the Prototype →</button>
          <p style={{ fontSize:11,color:"#ccc8c2",marginTop:12 }}>No sign-up needed. Explore the concept.</p>
        </div>
        <div style={{ height:56 }}/>
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════ */
const AppShell = ({ onBack }) => {
  const [activeTab,    setActiveTab]    = useState("feed");
  const [showCompare,  setShowCompare]  = useState(null);
  const [liked,        setLiked]        = useState({});
  const [wishlist,     setWishlist]     = useState({});
  const [animIn,       setAnimIn]       = useState(false);
  const [showDetail,   setShowDetail]   = useState(null);
  const [rankFilter,   setRankFilter]   = useState("All");
  const [discFilter,   setDiscFilter]   = useState("All");
  const [logCategory,  setLogCategory]  = useState("Play");
  const [rating,       setRating]       = useState(0);
  const [selTags,      setSelTags]      = useState({});
  useEffect(()=>{ setTimeout(()=>setAnimIn(true),50); },[]);
  const tabs = [
    { key:"feed",     label:"Feed",    icon:"⊙" },
    { key:"discover", label:"Discover",icon:"◈" },
    { key:"log",      label:"Log",     icon:"+" },
    { key:"ranked",   label:"My List", icon:"≡" },
    { key:"profile",  label:"Profile", icon:"◎" },
  ];
  const filteredRanked  = rankFilter==="All" ? MY_LOGGED : MY_LOGGED.filter(s=>s.category===rankFilter);
  const filteredDiscover= discFilter==="All"  ? SHOWS_DB  : SHOWS_DB.filter(s=>s.category===discFilter);

  return (
    <div style={{ minHeight:"100vh",background:"#f2eeea",fontFamily:"'DM Sans',sans-serif",color:"#1a1816",display:"flex",justifyContent:"center" }}>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
      <div style={{ width:"100%",maxWidth:430,minHeight:"100vh",background:"#faf8f5",position:"relative",boxShadow:"0 0 60px rgba(0,0,0,0.06)" }}>
        {/* Header */}
        <div style={{ padding:"18px 20px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid #ebe6df",background:"#faf8f5",position:"sticky",top:0,zIndex:40 }}>
          <div style={{ display:"flex",alignItems:"center",gap:12 }}>
            <button onClick={onBack} style={{ background:"none",border:"none",cursor:"pointer",fontSize:18,color:"#8a8580",padding:0,lineHeight:1 }}>←</button>
            <div>
              <h1 style={{ fontSize:22,fontWeight:700,margin:0,fontFamily:"'Playfair Display',serif",color:"#1a1816",letterSpacing:-0.5 }}>Curtain Call</h1>
              <p style={{ fontSize:9,color:"#b5b0ab",margin:"1px 0 0",letterSpacing:3,textTransform:"uppercase",fontFamily:"'JetBrains Mono',monospace" }}>Track · Rank · Discover</p>
            </div>
          </div>
          <div style={{ width:32,height:32,borderRadius:"50%",background:"#1a1816",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,color:"#fff",fontWeight:700,fontFamily:"'Playfair Display',serif" }}>A</div>
        </div>

        <div style={{ height:"calc(100vh - 120px)",overflowY:"auto",paddingBottom:80 }}>

          {/* ── FEED ── */}
          {activeTab==="feed" && (
            <div style={{ opacity:animIn?1:0,transition:"opacity 0.4s" }}>
              <div style={{ padding:"14px 20px 6px",display:"flex",gap:14,overflowX:"auto" }}>
                {FRIENDS.map(f=>(
                  <div key={f.id} style={{ textAlign:"center",minWidth:58 }}>
                    <div style={{ width:46,height:46,borderRadius:"50%",background:"#f0ece6",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,border:"2px solid #e8e3dc",margin:"0 auto 4px" }}>{f.avatar}</div>
                    <p style={{ fontSize:10,color:"#6a6560",margin:0,fontWeight:600 }}>{f.name.split(" ")[0]}</p>
                    <p style={{ fontSize:9,color:"#c8860a",margin:0,fontFamily:"'JetBrains Mono',monospace" }}>{f.match}%</p>
                  </div>
                ))}
              </div>
              <div style={{ padding:"12px 20px",display:"flex",flexDirection:"column",gap:14 }}>
                {FEED_ITEMS.map((item,idx)=>(
                  <div key={idx} style={{ background:"#fff",borderRadius:16,padding:18,border:"1px solid #ebe6df",boxShadow:"0 1px 4px rgba(0,0,0,0.03)",opacity:animIn?1:0,transform:animIn?"translateY(0)":"translateY(16px)",transition:`all 0.4s ease ${idx*0.07}s` }}>
                    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10 }}>
                      <div style={{ display:"flex",gap:10,alignItems:"center" }}>
                        <span style={{ fontSize:22 }}>{item.avatar}</span>
                        <div>
                          <p style={{ margin:0,fontSize:13,fontWeight:600 }}>{item.user}</p>
                          <p style={{ margin:0,fontSize:11,color:"#b5b0ab" }}>{item.time}</p>
                        </div>
                      </div>
                      <div style={{ textAlign:"right" }}>
                        <StarRating rating={item.rating} size={12}/>
                        <p style={{ margin:"2px 0 0",fontSize:9,color:"#b5b0ab" }}>{item.showCategory}</p>
                      </div>
                    </div>
                    <h4 style={{ margin:"0 0 6px",fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:600 }}>{item.show}</h4>
                    <p style={{ margin:"0 0 12px",fontSize:13,color:"#6a6560",lineHeight:1.55 }}>{item.text}</p>
                    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                      <div style={{ display:"flex",gap:6 }}>{item.tags.map(t=><Tag key={t} label={t}/>)}<Tag label={item.showCategory} accent/></div>
                      <button onClick={()=>setLiked(p=>({...p,[idx]:!p[idx]}))} style={{ background:"none",border:"none",cursor:"pointer",color:liked[idx]?"#c8860a":"#ccc8c2",fontSize:13,display:"flex",alignItems:"center",gap:4 }}>
                        {liked[idx]?"♥":"♡"} {item.likes+(liked[idx]?1:0)}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── DISCOVER ── */}
          {activeTab==="discover" && (
            <div style={{ padding:"16px 20px" }}>
              <div style={{ background:"#fff",borderRadius:14,padding:"11px 16px",display:"flex",alignItems:"center",gap:10,marginBottom:16,border:"1.5px solid #ebe6df" }}>
                <span style={{ color:"#ccc8c2",fontSize:16 }}>⌕</span>
                <input type="text" placeholder="Search shows, venues, cast..." style={{ background:"none",border:"none",color:"#1a1816",fontSize:14,outline:"none",width:"100%",fontFamily:"'DM Sans',sans-serif" }}/>
              </div>
              <div style={{ display:"flex",gap:8,overflowX:"auto",marginBottom:20,paddingBottom:4 }}>
                {CATEGORIES.map(c=><CategoryPill key={c} label={c} active={discFilter===c} onClick={()=>setDiscFilter(c)} count={c==="All"?SHOWS_DB.length:SHOWS_DB.filter(s=>s.category===c).length}/>)}
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
                {filteredDiscover.map((show,idx)=>(
                  <div key={show.id} onClick={()=>setShowDetail(show)} style={{ display:"flex",gap:14,background:"#fff",borderRadius:14,padding:14,border:"1px solid #ebe6df",cursor:"pointer",transition:"all 0.2s",opacity:animIn?1:0,transform:animIn?"translateX(0)":"translateX(16px)",transitionDelay:`${idx*0.03}s` }}>
                    <div style={{ width:52,height:52,borderRadius:12,background:"#f5f1ec",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,flexShrink:0 }}>{show.img}</div>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start" }}>
                        <h4 style={{ margin:0,fontSize:14,fontFamily:"'Playfair Display',serif",fontWeight:600 }}>{show.title}</h4>
                        <StarRating rating={show.rating} size={11}/>
                      </div>
                      <p style={{ margin:"2px 0 6px",fontSize:11,color:"#8a8580" }}>{show.venue}</p>
                      <div style={{ display:"flex",gap:5 }}><Tag label={show.category} accent/>{show.tags.slice(0,1).map(t=><Tag key={t} label={t}/>)}</div>
                    </div>
                    <button onClick={e=>{e.stopPropagation();setWishlist(p=>({...p,[show.id]:!p[show.id]}));}} style={{ background:"none",border:"none",cursor:"pointer",color:wishlist[show.id]?"#c8860a":"#ddd7cf",fontSize:20,alignSelf:"center",padding:4 }}>{wishlist[show.id]?"★":"☆"}</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── LOG ── */}
          {activeTab==="log" && (
            <div style={{ padding:"16px 20px" }}>
              <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:22,marginBottom:2 }}>Log a Show</h3>
              <p style={{ color:"#8a8580",fontSize:12,marginBottom:20,fontFamily:"'JetBrains Mono',monospace" }}>Rate it. Rank it within its category. Remember it.</p>
              <div style={{ background:"#fff",borderRadius:16,padding:22,border:"1px solid #ebe6df",marginBottom:14 }}>
                <div style={{ background:"#faf8f5",borderRadius:10,padding:"11px 16px",display:"flex",alignItems:"center",gap:10,marginBottom:20,border:"1.5px solid #ebe6df" }}>
                  <span style={{ color:"#ccc8c2" }}>⌕</span>
                  <input type="text" placeholder="What did you see?" style={{ background:"none",border:"none",color:"#1a1816",fontSize:15,outline:"none",width:"100%",fontFamily:"'DM Sans',sans-serif" }}/>
                </div>
                <p style={{ fontSize:11,color:"#8a8580",marginBottom:8,fontFamily:"'JetBrains Mono',monospace",letterSpacing:1 }}>CATEGORY</p>
                <div style={{ display:"flex",gap:8,flexWrap:"wrap",marginBottom:20 }}>
                  {CATEGORIES.filter(c=>c!=="All").map(c=><CategoryPill key={c} label={c} active={logCategory===c} onClick={()=>setLogCategory(c)}/>)}
                </div>
                <p style={{ fontSize:11,color:"#8a8580",marginBottom:8,fontFamily:"'JetBrains Mono',monospace",letterSpacing:1 }}>YOUR RATING</p>
                <div style={{ display:"flex",gap:6,marginBottom:20 }}>
                  {[1,2,3,4,5].map(n=>(
                    <span key={n} onClick={()=>setRating(n)} style={{ fontSize:30,cursor:"pointer",color:"#c8860a",opacity:n<=rating?1:0.25,transition:"all 0.15s" }}>★</span>
                  ))}
                </div>
                <p style={{ fontSize:11,color:"#8a8580",marginBottom:8,fontFamily:"'JetBrains Mono',monospace",letterSpacing:1 }}>DATE SEEN</p>
                <input type="date" style={{ background:"#faf8f5",border:"1.5px solid #ebe6df",borderRadius:10,padding:"10px 14px",color:"#1a1816",fontSize:13,width:"100%",fontFamily:"'DM Sans',sans-serif",marginBottom:20,boxSizing:"border-box" }}/>
                <p style={{ fontSize:11,color:"#8a8580",marginBottom:8,fontFamily:"'JetBrains Mono',monospace",letterSpacing:1 }}>REVIEW</p>
                <textarea placeholder="How was it? What stood out?" style={{ background:"#faf8f5",border:"1.5px solid #ebe6df",borderRadius:10,padding:14,color:"#1a1816",fontSize:13,width:"100%",minHeight:80,fontFamily:"'DM Sans',sans-serif",resize:"vertical",boxSizing:"border-box" }}/>
                <p style={{ fontSize:11,color:"#8a8580",margin:"18px 0 8px",fontFamily:"'JetBrains Mono',monospace",letterSpacing:1 }}>TAGS</p>
                <div style={{ display:"flex",flexWrap:"wrap",gap:8,marginBottom:24 }}>
                  {["Must-See","Overrated","Emotional","Funny","Dark","Spectacle","Intimate","Perfect Cast","Date Night","Mind-Blown"].map(tag=>(
                    <button key={tag} onClick={()=>setSelTags(p=>({...p,[tag]:!p[tag]}))} style={{ background:selTags[tag]?"rgba(200,134,10,0.06)":"#faf8f5",color:selTags[tag]?"#c8860a":"#6a6560",border:`1.5px solid ${selTags[tag]?"#c8860a":"#e8e3dc"}`,borderRadius:20,padding:"6px 14px",fontSize:11,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",transition:"all 0.2s" }}>{tag}</button>
                  ))}
                </div>
                <button onClick={()=>setShowCompare({ show:"My New Show",category:logCategory })} style={{ width:"100%",padding:"14px 0",background:"#1a1816",color:"#fff",border:"none",borderRadius:12,fontSize:14,fontWeight:700,cursor:"pointer" }}>Log & Rank in {logCategory} →</button>
                <p style={{ textAlign:"center",fontSize:11,color:"#b5b0ab",marginTop:10 }}>You'll compare against your other {logCategory.toLowerCase()}s only</p>
              </div>
            </div>
          )}

          {/* ── MY LIST ── */}
          {activeTab==="ranked" && (
            <div style={{ padding:"16px 20px" }}>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:14 }}>
                <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:22,margin:0 }}>My Rankings</h3>
                <span style={{ fontSize:11,color:"#b5b0ab" }}>{filteredRanked.length} shows</span>
              </div>
              <div style={{ display:"flex",gap:8,overflowX:"auto",marginBottom:16,paddingBottom:4 }}>
                {CATEGORIES.map(c=>{ const count=c==="All"?MY_LOGGED.length:MY_LOGGED.filter(s=>s.category===c).length; if(c!=="All"&&count===0)return null; return <CategoryPill key={c} label={c} active={rankFilter===c} onClick={()=>setRankFilter(c)} count={count}/>; })}
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
                {filteredRanked.map((item,idx)=>{
                  const show=SHOWS_DB.find(s=>s.title===item.show);
                  const displayRank=rankFilter==="All"?item.rank:item.categoryRank;
                  return (
                    <div key={idx} style={{ display:"flex",gap:12,alignItems:"center",background:"#fff",borderRadius:14,padding:"12px 14px",border:displayRank===1?"1.5px solid rgba(200,134,10,0.25)":"1px solid #ebe6df",opacity:animIn?1:0,transform:animIn?"translateX(0)":"translateX(-12px)",transition:`all 0.3s ease ${idx*0.04}s` }}>
                      <RankBadge rank={displayRank}/>
                      <div style={{ width:40,height:40,borderRadius:10,background:"#f5f1ec",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>{show?.img||"🎭"}</div>
                      <div style={{ flex:1 }}>
                        <h4 style={{ margin:0,fontSize:14,fontFamily:"'Playfair Display',serif",fontWeight:600 }}>{item.show}</h4>
                        <div style={{ display:"flex",gap:6,alignItems:"center",marginTop:2 }}><Tag label={item.category} accent/><span style={{ fontSize:10,color:"#b5b0ab" }}>{item.date}</span></div>
                      </div>
                      <StarRating rating={item.rating} size={11}/>
                    </div>
                  );
                })}
              </div>
              <div style={{ background:"#fff",borderRadius:16,padding:20,marginTop:20,border:"1px solid #ebe6df",textAlign:"center" }}>
                <p style={{ fontSize:10,color:"#c8860a",fontFamily:"'JetBrains Mono',monospace",letterSpacing:2,marginBottom:6 }}>LEADERBOARD</p>
                <p style={{ fontSize:15,margin:"0 0 12px" }}>You're ranked <strong style={{ color:"#c8860a",fontFamily:"'Playfair Display',serif",fontSize:20 }}>#147</strong> overall</p>
                <div style={{ display:"flex",justifyContent:"center",gap:16 }}>
                  {[{n:"Sophie K.",r:12},{n:"Priya L.",r:34},{n:"Nona",r:89}].map(f=><span key={f.n} style={{ fontSize:11,color:"#8a8580" }}>{f.n} <strong style={{ color:"#c8860a" }}>#{f.r}</strong></span>)}
                </div>
              </div>
            </div>
          )}

          {/* ── PROFILE ── */}
          {activeTab==="profile" && (
            <div style={{ padding:"16px 20px" }}>
              <div style={{ textAlign:"center",marginBottom:24 }}>
                <div style={{ width:72,height:72,borderRadius:"50%",background:"#1a1816",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,color:"#fff",margin:"0 auto 12px",fontFamily:"'Playfair Display',serif",fontWeight:700,boxShadow:"0 4px 16px rgba(0,0,0,0.12)" }}>A</div>
                <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:20,margin:"0 0 3px" }}>Alex A.</h3>
                <p style={{ color:"#8a8580",fontSize:12,margin:0 }}>{TASTE_PROFILE.totalShows} shows logged</p>
              </div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:18 }}>
                {[{label:"Shows",value:TASTE_PROFILE.totalShows},{label:"Avg Rating",value:TASTE_PROFILE.avgRating.toFixed(1)}].map(s=>(
                  <div key={s.label} style={{ background:"#fff",borderRadius:14,padding:16,textAlign:"center",border:"1px solid #ebe6df" }}>
                    <p style={{ fontSize:24,fontWeight:700,margin:0,fontFamily:"'Playfair Display',serif" }}>{s.value}</p>
                    <p style={{ fontSize:9,color:"#b5b0ab",margin:"4px 0 0",fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:1.5 }}>{s.label}</p>
                  </div>
                ))}
              </div>
              <div style={{ background:"#fff",borderRadius:16,padding:18,border:"1px solid #ebe6df",marginBottom:14 }}>
                <h4 style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#c8860a",letterSpacing:2,margin:"0 0 14px" }}>CATEGORY #1S</h4>
                {[...new Set(MY_LOGGED.map(s=>s.category))].map(cat=>{
                  const top=MY_LOGGED.filter(s=>s.category===cat).sort((a,b)=>a.categoryRank-b.categoryRank)[0];
                  return (<div key={cat} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}><div><p style={{ margin:"0 0 3px",fontSize:14,fontWeight:600,fontFamily:"'Playfair Display',serif" }}>{top.show}</p><Tag label={cat} accent/></div><StarRating rating={top.rating} size={12}/></div>);
                })}
              </div>
              <div style={{ background:"#fff",borderRadius:16,padding:18,border:"1px solid #ebe6df",marginBottom:14 }}>
                <h4 style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#c8860a",letterSpacing:2,margin:"0 0 14px" }}>TASTE PROFILE</h4>
                {Object.entries(TASTE_PROFILE.genreBreakdown).map(([genre,pct])=>(
                  <div key={genre} style={{ marginBottom:10 }}>
                    <div style={{ display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:4 }}><span style={{ color:"#4a4540" }}>{genre}</span><span style={{ color:"#b5b0ab" }}>{pct}%</span></div>
                    <div style={{ height:5,background:"#f0ece6",borderRadius:3 }}><div style={{ height:"100%",width:`${pct}%`,borderRadius:3,background:"linear-gradient(90deg,#c8860a,#e0a832)" }}/></div>
                  </div>
                ))}
              </div>
              <div style={{ background:"#fff",borderRadius:16,padding:18,border:"1px solid #ebe6df",marginBottom:14 }}>
                <h4 style={{ fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:"#c8860a",letterSpacing:2,margin:"0 0 14px" }}>BADGES</h4>
                <div style={{ display:"flex",flexWrap:"wrap",gap:8 }}>
                  {TASTE_PROFILE.badges.map(b=><span key={b} style={{ background:"rgba(200,134,10,0.06)",color:"#c8860a",padding:"6px 14px",borderRadius:20,fontSize:11,fontWeight:600,border:"1px solid rgba(200,134,10,0.12)" }}>✦ {b}</span>)}
                </div>
              </div>
              <div style={{ background:"#1a1816",borderRadius:16,padding:22,textAlign:"center",cursor:"pointer" }}>
                <p style={{ fontSize:20,fontWeight:700,margin:"0 0 4px",color:"#fff",fontFamily:"'Playfair Display',serif" }}>2025 Year in Review</p>
                <p style={{ fontSize:12,color:"#8a8580",margin:0 }}>Your theatrical year, wrapped →</p>
              </div>
            </div>
          )}
        </div>

        {/* Show detail sheet */}
        {showDetail && (
          <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.35)",zIndex:90,display:"flex",alignItems:"flex-end",justifyContent:"center",backdropFilter:"blur(6px)" }} onClick={()=>setShowDetail(null)}>
            <div onClick={e=>e.stopPropagation()} style={{ background:"#faf8f5",borderRadius:"22px 22px 0 0",padding:"22px 20px 36px",maxWidth:430,width:"100%",maxHeight:"78vh",overflowY:"auto" }}>
              <div style={{ width:36,height:4,background:"#ddd7cf",borderRadius:2,margin:"0 auto 18px" }}/>
              <div style={{ display:"flex",gap:16,marginBottom:18 }}>
                <div style={{ width:72,height:72,borderRadius:16,background:"#f0ece6",display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,flexShrink:0 }}>{showDetail.img}</div>
                <div>
                  <h2 style={{ fontFamily:"'Playfair Display',serif",fontSize:22,margin:"0 0 3px" }}>{showDetail.title}</h2>
                  <p style={{ color:"#8a8580",fontSize:13,margin:"0 0 8px" }}>{showDetail.venue}</p>
                  <div style={{ display:"flex",gap:6,alignItems:"center" }}><StarRating rating={showDetail.rating} size={14}/><Tag label={showDetail.category} accent/></div>
                </div>
              </div>
              <div style={{ display:"flex",gap:6,marginBottom:18,flexWrap:"wrap" }}>{showDetail.tags.map(t=><Tag key={t} label={t}/>)}</div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:18 }}>
                {[{v:showDetail.critics,l:"Critics"},{v:showDetail.audience,l:"Audience"}].map(s=>(
                  <div key={s.l} style={{ background:"#fff",borderRadius:12,padding:14,textAlign:"center",border:"1px solid #ebe6df" }}>
                    <p style={{ fontSize:26,fontWeight:700,margin:0,fontFamily:"'Playfair Display',serif" }}>{s.v}%</p>
                    <p style={{ fontSize:9,color:"#b5b0ab",margin:"4px 0 0",letterSpacing:1.5 }}>{s.l.toUpperCase()}</p>
                  </div>
                ))}
              </div>
              <p style={{ fontSize:10,color:"#b5b0ab",marginBottom:3,letterSpacing:1 }}>CAST</p>
              <p style={{ fontSize:14,marginBottom:18 }}>{showDetail.cast.join(", ")}</p>
              {showDetail.endDate && <p style={{ fontSize:12,color:"#c8860a",marginBottom:18 }}>⏰ Closes {showDetail.endDate}</p>}
              <div style={{ display:"flex",gap:10 }}>
                <button onClick={()=>{ setShowDetail(null); setActiveTab("log"); setLogCategory(showDetail.category); }} style={{ flex:1,padding:"14px 0",background:"#1a1816",color:"#fff",border:"none",borderRadius:12,fontSize:14,fontWeight:700,cursor:"pointer" }}>Log This Show</button>
                <button onClick={()=>setWishlist(p=>({...p,[showDetail.id]:!p[showDetail.id]}))} style={{ padding:"14px 18px",background:"#fff",border:"1.5px solid #ebe6df",borderRadius:12,color:wishlist[showDetail.id]?"#c8860a":"#ccc8c2",fontSize:20,cursor:"pointer" }}>{wishlist[showDetail.id]?"★":"☆"}</button>
              </div>
            </div>
          </div>
        )}

        {showCompare && <CompareModal show={showCompare.show} category={showCompare.category} existingShows={MY_LOGGED} onClose={()=>setShowCompare(null)}/>}

        {/* Bottom nav */}
        <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,background:"#faf8f5",borderTop:"1px solid #ebe6df",display:"flex",zIndex:50,paddingBottom:"env(safe-area-inset-bottom,6px)" }}>
          {tabs.map(tab=>(
            <button key={tab.key} onClick={()=>{ setActiveTab(tab.key); setAnimIn(false); setTimeout(()=>setAnimIn(true),30); }}
              style={{ flex:1,background:"none",border:"none",padding:"11px 0 7px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:2,color:activeTab===tab.key?"#1a1816":(tab.key==="log"?"#c8860a":"#ccc8c2") }}>
              <span style={{ fontSize:tab.key==="log"?24:17,fontWeight:tab.key==="log"?700:400 }}>{tab.icon}</span>
              <span style={{ fontSize:9,textTransform:"uppercase",letterSpacing:0.8,fontWeight:activeTab===tab.key?700:400 }}>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default function CurtainCall() {
  const [entered, setEntered] = useState(false);
  if (entered) return <AppShell onBack={()=>setEntered(false)}/>;
  return <LandingPage onEnter={()=>setEntered(true)}/>;
}
